/* $Id: rawtest.c,v 1.17 2002/11/29 12:16:15 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <err.h>
#include <math.h>

#include <raw.h>

#ifdef PNG
#include <png.h>
#endif

#include <jpeglib.h>

void write_jpeg(struct raw *raw, FILE *ofp);

#ifdef PNG
void write_png(struct raw *raw, FILE *ofp);
#endif

int main(int argc, char *argv[])
{
	int fd;
	struct raw *r;
	FILE *jpeg_fp;
#ifdef PNG
	FILE *png_fp;
#endif
	int i, red, green, blue;

	if ((r = open_raw(argv[1])) == NULL) {
		errx(1, "file %s could not be opened", argv[1]);
	}

	if (r->jpegthumbnail) {
		printf("JPEG thumbnail found: addr %u size %u - saving\n",
		       r->jpegthumbnail->data, r->jpegthumbnail->size);
		if ((fd = open("thumb.jpg", O_WRONLY|O_CREAT, 0644)) == -1) {
			err(1, "cannot open thumb.jpg for writing");
		}
		write(fd, r->data + r->jpegthumbnail->data,
		      r->jpegthumbnail->size);
		close(fd);
		
	}

	if (strncmp("Canon", r->manufacturer, 6) == 0) {
		if (strncmp("Canon EOS D30", r->model, 14) == 0) {
			canon_decode_d30(r);
		} else if (strncmp("Canon EOS D60", r->model, 14) == 0) {
			canon_decode_d60(r);
		}
	} else {
		err(1, "Unknown camera %s model %s", r->manufacturer, r->model);
		exit(0);
	}

	cfa_subtract_black(r, r->sensor.x_offset / 2, r->sensor.y_offset);

	cfa_wb(r, 0, WB_AUTO);

#if 0
	if ((fd = open("sensor.data", O_WRONLY|O_CREAT, 0644)) == -1) {
		err(1, "cannot open sensor.data for writing");
	}
	write(fd, r->sensorarray,
	      r->sensor.width * r->sensor.height * sizeof(SENSORELEMENT_T));
	close(fd);
#endif

	cfa_demosaick(r, CFA_ALG_CCP,
		      r->sensor.x_offset, r->sensor.y_offset,
		      r->sensor.x_out, r->sensor.y_out);

#if 0
	if ((fd = open("red.data", O_WRONLY|O_CREAT, 0644)) == -1) {
		err(1, "cannot open reddata");
	}
	write(fd, r->rawrgb_r,
	      r->rawrgb_x * r->rawrgb_y * sizeof(COLOURDEPTH_T));
	close(fd);

	if ((fd = open("green.data", O_WRONLY|O_CREAT, 0644)) == -1) {
		err(1, "cannot open greendata");
	}
	write(fd, r->rawrgb_g,
	      r->rawrgb_x * r->rawrgb_y * sizeof(COLOURDEPTH_T));
	close(fd);

	if ((fd = open("blue.data", O_WRONLY|O_CREAT, 0644)) == -1) {
		err(1, "cannot open bluedata");
	}
	write(fd, r->rawrgb_b,
	      r->rawrgb_x * r->rawrgb_y * sizeof(COLOURDEPTH_T));
	close(fd);
#endif

#if 1
	if ((jpeg_fp = fopen("image.jpg", "w")) == NULL) {
		err(1, "cannot open jpeg.jpg");
	}
	write_jpeg(r, jpeg_fp);
	fclose(jpeg_fp);
#endif

#ifdef PNG
	if ((png_fp = fopen("image.png", "w")) == NULL) {
		err(1, "cannot open image.jpg");
	}
	write_png(r, png_fp);
	fclose(png_fp);
#endif

	close_raw(r);

	exit(0);
}

void TransformRGB2HSL(
		u_int16_t red, u_int16_t green, u_int16_t blue,
		double* hue, double* saturation, double* luminosity,
		int MaxRGB
		)
{
	double r, g, b;
	double delta, max, min;

	/* Convert RGB to HSL colorspace */
	r = (double)red / MaxRGB;
	g = (double)green / MaxRGB;
	b = (double)blue / MaxRGB;
	max = r > g ? r : g; if (b > max) max = b;
	min = r < g ? r : g; if (b < min) min = b;
	*hue = -1.0;
	*saturation = 0.0;
	*luminosity = (min + max) / 2.0;
	delta = max - min;
	if (delta == 0.0) return;

	*saturation=delta/((*luminosity <= 0.5) ? (min+max) : (2.0-max-min));
	if (r == max)
	{
		*hue=(g == min ? 5.0+(max-b)/delta : 1.0-(max-g)/delta);
	}
	else
	{
		if (g == max)
		{
			*hue=(b == min ? 1.0+(max-r)/delta : 3.0-(max-b)/delta);
		}
		else
		{
			*hue=(r == min ? 3.0+(max-g)/delta : 5.0-(max-r)/delta);
		}
	}
	*hue/=6.0;
}

void TransformHSL2RGB(
		double hue, double saturation, double luminosity,
		u_int16_t* red, u_int16_t* green, u_int16_t* blue,
		int MaxRGB
		)
{
	double r, g, b;
	double v, x, y, z;

	/* Convert HSL to RGB colorspace */
	v = (luminosity <= 0.5) ? (luminosity*(1.0+saturation)) :
		(luminosity+saturation-luminosity*saturation);
	if ((saturation == 0.0) || (hue == -1.0))
	{
		*red=(u_int16_t) (MaxRGB*luminosity+0.5);
		*green=(u_int16_t) (MaxRGB*luminosity+0.5);
		*blue=(u_int16_t) (MaxRGB*luminosity+0.5);
		return;
	}
	y=2.0*luminosity-v;
	x=y+(v-y)*(6.0*hue-floor(6.0*hue));
	z=v-(v-y)*(6.0*hue-floor(6.0*hue));
	switch ((int) (6.0*hue))
	{
	case 0: r=v; g=x; b=y; break;
	case 1: r=z; g=v; b=y; break;
	case 2: r=y; g=v; b=x; break;
	case 3: r=y; g=z; b=v; break;
	case 4: r=x; g=y; b=v; break;
	case 5: r=v; g=y; b=z; break;
	default: r=v; g=x; b=y; break;
	}
	*red=(u_int16_t) (MaxRGB*r+0.5);
	*green=(u_int16_t) (MaxRGB*g+0.5);
	*blue=(u_int16_t) (MaxRGB*b+0.5);
}

#if 1

void
write_jpeg(struct raw *raw, FILE *ofp)
{
	struct jpeg_compress_struct cinfo;
	struct jpeg_error_mgr jerr;
	JSAMPROW row_pointer[1];
	int row_stride;
	u_int8_t *data;
	int x;
	u_int8_t red_levels_map[256 * 256];
	u_int8_t green_levels_map[256 * 256];
	u_int8_t blue_levels_map[256 * 256];

#ifdef DEBUG
  fprintf(stderr,"Writing JPEG file...\n");
#endif

	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_compress(&cinfo);
	jpeg_stdio_dest(&cinfo, ofp);

	cinfo.image_width = raw->rawrgb_x;
	cinfo.image_height = raw->rawrgb_y;
	cinfo.input_components = raw->rawrgb_d;
	cinfo.in_color_space = JCS_RGB;

	jpeg_set_defaults(&cinfo);
	jpeg_set_quality(&cinfo, 99, TRUE);
	jpeg_start_compress(&cinfo, TRUE);

	row_stride = cinfo.image_width * raw->rawrgb_d;

	if((data = (char *)malloc(row_stride)) == NULL) {
		warn("malloc failed");
	}


	{
		int red_levels[256 * 256];
		int blue_levels[256 * 256];
		int green_levels[256 * 256];

		u_int16_t* red = (u_int16_t*)raw->rawrgb_r;
		u_int16_t* green = (u_int16_t*)raw->rawrgb_g;
		u_int16_t* blue = (u_int16_t*)raw->rawrgb_b;

		int threshold = (raw->rawrgb_x * raw->rawrgb_y) / 10000;
		int sum = 0;

		int redBlackPoint = 0;
		double redMidPoint = 2.2;
		int redWhitePoint = 65534;

		int blueBlackPoint = 0;
		double blueMidPoint = 2.2;
		int blueWhitePoint = 65534;

		int greenBlackPoint = 0;
		double greenMidPoint = 2.2;
		int greenWhitePoint = 65534;

		int i;

		memset(red_levels, 0, sizeof(red_levels));
		memset(green_levels, 0, sizeof(green_levels));
		memset(blue_levels, 0, sizeof(blue_levels));

		/* boost the saturation a bit and calculate levels for
		R, G and B */
		for (x = 0; x < raw->rawrgb_x * raw->rawrgb_y; x++)
		{
			double h, l, s;
			TransformRGB2HSL(*red, *green, *blue, &h, &s, &l, 65534);
			s *= 1.8;
			if (s > 1.0) s = 1.0;
			TransformHSL2RGB(h, s, l, red, green, blue, 65534);

			red_levels[*red++]++;
			green_levels[*green++]++;
			blue_levels[*blue++]++;
		}

		/* calc white and black points for the R, G and B channels */
		sum = 0;
		for (x = 256 * 256 - 1; sum <= threshold; x--)
		{
			sum += red_levels[x];
			if (sum <= threshold) redWhitePoint = x;
		}
		sum = 0;
		for (x = 0; x < 256 * 256 && sum <= threshold; x++)
		{
			sum += red_levels[x];
			if (sum <= threshold) redBlackPoint = x;
		}
		sum = 0;
		for (x = 256 * 256 - 1; sum <= threshold; x--)
		{
			sum += green_levels[x];
			if (sum <= threshold) greenWhitePoint = x;
		}
		sum = 0;
		for (x = 0; x < 256 * 256 && sum <= threshold; x++)
		{
			sum += green_levels[x];
			if (sum <= threshold) greenBlackPoint = x;
		}
		sum = 0;
		for (x = 256 * 256 - 1; sum <= threshold; x--)
		{
			sum += blue_levels[x];
			if (sum <= threshold) blueWhitePoint = x;
		}
		sum = 0;
		for (x = 0; x < 256 * 256 && sum <= threshold; x++)
		{
			sum += blue_levels[x];
			if (sum <= threshold) blueBlackPoint = x;
		}
		printf("redBlackPoint:%d, redWhitePoint:%d\n", redBlackPoint, redWhitePoint);
		printf("greenBlackPoint:%d, greenWhitePoint:%d\n", greenBlackPoint, greenWhitePoint);
		printf("blueBlackPoint:%d, blueWhitePoint:%d\n", blueBlackPoint, blueWhitePoint);

#if 0
		/* quick hack to avoid losing too much highlight detail */
		/* and also see how it affects WB */
		{
			double temp;
			temp = redWhitePoint; temp *= 1.1; redWhitePoint = temp;
			temp = greenWhitePoint; temp *= 1.2; greenWhitePoint = temp;
			temp = blueWhitePoint; temp *= 1.2; blueWhitePoint = temp;
		}
#endif

		/* pre-calculate mapping tables to adjust levels for R, G and B channels */
		/* note: the mid point has the same effect as adjusting the gamma */
		for (i=0; i < 256 * 256; i++)
		{
			if (i > redWhitePoint)
			{
				red_levels_map[i] = 255;
			}
			else
			{
				red_levels_map[i]=(u_int8_t) ((pow((double) (i-redBlackPoint)/(redWhitePoint-redBlackPoint),1.0/redMidPoint)* 255)+0.5);
			}
			if (i > greenWhitePoint)
			{
				green_levels_map[i] = 255;
			}
			else
			{
				green_levels_map[i]=(u_int8_t) ((pow((double) (i-greenBlackPoint)/(greenWhitePoint-greenBlackPoint),1.0/greenMidPoint)* 255)+0.5);
			}
			if (i > blueWhitePoint)
			{
				blue_levels_map[i] = 255;
			}
			else
			{
				blue_levels_map[i]=(u_int8_t) ((pow((double) (i-blueBlackPoint)/(blueWhitePoint-blueBlackPoint),1.0/blueMidPoint)* 255)+0.5);
			}
		}
	}

	/* write out the JPEG row by row */
	while(cinfo.next_scanline < cinfo.image_height)
	{
		u_int8_t* dest = data;
		for(x = 0; x < cinfo.image_width; x++)
		{
			int off = x + cinfo.next_scanline * raw->rawrgb_x;

			*dest++ = red_levels_map[*(raw->rawrgb_r + off)];
			*dest++ = green_levels_map[*(raw->rawrgb_g + off)];
			*dest++ = blue_levels_map[*(raw->rawrgb_b + off)];
		}
		row_pointer[0] = data;
		jpeg_write_scanlines(&cinfo, row_pointer, 1);
	}

	jpeg_finish_compress(&cinfo);
	jpeg_destroy_compress(&cinfo);
	free(data);
}

#else

void
write_jpeg(struct raw *raw, FILE *ofp)
{
	struct jpeg_compress_struct cinfo;
	struct jpeg_error_mgr jerr;
	JSAMPROW row_pointer[1];
	int row_stride;
	u_int8_t *data;
	int x;
	u_int8_t red_levels_map[256 * 256];
	u_int8_t green_levels_map[256 * 256];
	u_int8_t blue_levels_map[256 * 256];

#ifdef DEBUG
  fprintf(stderr,"Writing JPEG file...\n");
#endif

	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_compress(&cinfo);
	jpeg_stdio_dest(&cinfo, ofp);

	cinfo.image_width	= raw->rawrgb_x;
	cinfo.image_height	= raw->rawrgb_y;
	cinfo.input_components	= raw->rawrgb_d;
	cinfo.in_color_space	= JCS_RGB;

#ifdef DEBUG
	fprintf(stderr, "writing jpeg X(%d) x Y(%d) x RGB(%d)\n",
		cinfo.image_width, cinfo.image_height, cinfo.input_components);
#endif

	jpeg_set_defaults(&cinfo);
	jpeg_set_quality(&cinfo, 99, TRUE);
	jpeg_start_compress(&cinfo, TRUE);

	row_stride = cinfo.image_width * cinfo.input_components;

	if((data = (char *) malloc(row_stride)) == NULL) {
		warn("malloc failed");
	}

	row_pointer[0] = data;

	while(cinfo.next_scanline < cinfo.image_height) {
		for(x = 0; x < cinfo.image_width; x++) {
			int off = x + (cinfo.next_scanline * cinfo.image_width);

			data[x * 3]     = *(raw->rawrgb_r + off) >> 8;
			data[x * 3 + 1] = *(raw->rawrgb_g + off) >> 8;
			data[x * 3 + 2] = *(raw->rawrgb_b + off) >> 8;
		}
		jpeg_write_scanlines(&cinfo, row_pointer, 1);
	}

	jpeg_finish_compress(&cinfo);
	jpeg_destroy_compress(&cinfo);
	free(data);
}

#endif

#ifdef PNG
void
write_png(struct raw *raw, FILE *ofp)
{
	png_structp png_ptr;
	png_infop info_ptr;
	png_uint_16 *row_data;
	int x, y;

#ifdef DEBUG
	fprintf(stderr,"Writing PNG file...\n");
#endif

	if ((row_data = malloc(raw->rawrgb_x * 3 * sizeof(png_uint_16))) == NULL) {
		return;
	}

	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
					  NULL, NULL, NULL);
	if (!png_ptr) {
		free(row_data);
		return;
	}

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) {
		free(row_data);
		png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
		return;
	}

	if (setjmp(png_ptr->jmpbuf)) {
		free(row_data);
		png_destroy_write_struct(&png_ptr, &info_ptr);
		return;
	}

	png_init_io (png_ptr, ofp);
	png_set_IHDR (png_ptr, info_ptr, raw->rawrgb_x, raw->rawrgb_y, 16,
		      PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
		      PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);

	png_write_info(png_ptr, info_ptr);

	if (0xaa55 != htons(0xaa55))
		png_set_swap(png_ptr);

	for (y=0; y < raw->rawrgb_y; y++) {
		for (x = 0; x < raw->rawrgb_x; x++) {
			int off = x + y * raw->rawrgb_x;

			*(row_data + x * 3)     = *(raw->rawrgb_r + off);
			*(row_data + x * 3 + 1) = *(raw->rawrgb_g + off);
			*(row_data + x * 3 + 2) = *(raw->rawrgb_b + off);
		}
		png_write_row(png_ptr, (png_byte *) row_data);
	}

	png_write_end(png_ptr, NULL);
	png_destroy_write_struct(&png_ptr, &info_ptr);
}
#endif
