/* $Id: access.c,v 1.5 2002/05/09 19:59:55 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Read a RAW file, identify it, build the right data structures
 */

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>
#include <sys/types.h>
#ifdef HAVE_MMAP
#include <sys/mman.h>
#endif
#include <sys/stat.h>
#include <machine/endian.h>

#include <raw.h>

u_int8_t
raw_read_uint8(const struct raw *raw, int where)
{
	if (where < 0 || where > raw->st.st_size - 1) {
		warnx("raw_read_uint8: failing to read @ 0x%08x (0x%16llx)", where, raw->st.st_size);
		return 0;
	}

	return *((u_int8_t *)raw->data + where);
}

u_int16_t
raw_read_uint16(const struct raw *raw, int where)
{
	u_int16_t data;

	if (where < 0 || raw->st.st_size < where + sizeof(u_int16_t)) {
		warnx("raw_read_uint16: failing to read @ 0x%08x (0x%16llx)", where, raw->st.st_size);
		return 0;
	}

	bcopy(raw->data + where, &data, sizeof(u_int16_t));

	return (raw->endian == RAW_ENDIAN_BE) ? betoh16(data) : letoh16(data);
}

int16_t
raw_read_int16(const struct raw *raw, int where)
{
	int16_t data;

	if (where < 0 || raw->st.st_size < where + sizeof(u_int16_t)) {
		warnx("raw_read_uint16: failing to read @ 0x%08x (0x%16llx)", where, raw->st.st_size);
		return 0;
	}

	bcopy(raw->data + where, &data, sizeof(int16_t));

	return (raw->endian == RAW_ENDIAN_BE) ? betoh16(data) : letoh16(data);
}

u_int32_t
raw_read_uint32(const struct raw *raw, int where)
{
	u_int32_t data;

	if (where < 0 || raw->st.st_size < where + sizeof(u_int32_t)) {
		warnx("raw_read_uint32: failing to read @ 0x%08x", where);
		return 0;
	}

	bcopy(raw->data + where, &data, sizeof(u_int32_t));

	return (raw->endian == RAW_ENDIAN_BE) ? betoh32(data) : letoh32(data);
}

int32_t
raw_read_sint32(const struct raw *raw, int where)
{
	int32_t data;

	if (where < 0 || raw->st.st_size < where + sizeof(int32_t)) {
		warnx("raw_read_uint32: failing to read @ 0x%08x", where);
		return 0;
	}

	bcopy(raw->data + where, &data, sizeof(int32_t));

	return (raw->endian == RAW_ENDIAN_BE) ? betoh32(data) : letoh32(data);
}

float
raw_read_float32(const struct raw *raw, int where)
{
	float data;

	if (where < 0 || raw->st.st_size < where + sizeof(float)) {
		warnx("raw_read_float: failing to read @ 0x%08x", where);
		return 0;
	}

	bcopy(raw->data + where, &data, sizeof(float));

	return (raw->endian == RAW_ENDIAN_BE) ? betoh32(data) : letoh32(data);
}

char *
raw_read_ascii(const struct raw *raw, int where)
{
	return (char *) raw->data + where;
}
