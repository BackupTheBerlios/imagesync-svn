/* $Id: ciff.h,v 1.5 2002/05/09 19:59:55 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

struct ciff_heap {
	struct ciff_heap	*next;		/* next sibling */
	struct ciff_heap	*heap;		/* child heap if type ~ heap */
	int			data;
	size_t			size;
	u_int16_t		type;


};

#define	CIFF_HEADER_SIZE	26

/* type codes */
#define	CIFF_TC_ST_MASK		0xC000
#define	CIFF_TC_DT_MASK		0x3800
#define	CIFF_TC_ID_MASK		0x07FF

#define	CIFF_TC_ST_HEAP		0x0000
#define	CIFF_TC_ST_RECORD	0x4000

#define	CIFF_TC_DT_BYTE		0x0000
#define	CIFF_TC_DT_ASCII	0x0800
#define	CIFF_TC_DT_WORD		0x1000
#define	CIFF_TC_DT_DWORD	0x1800
#define	CIFF_TC_DT_BYTE2	0x2000
#define	CIFF_TC_DT_HEAP1	0x2800
#define	CIFF_TC_DT_HEAP2	0x3000

#define	CIFF_TC_ID_WILDCARD	0xffff
#define	CIFF_TC_ID_NULL		0x0000
#define	CIFF_TC_ID_FREE		0x0001
#define	CIFF_TC_ID_EXUSED	0x0002

/* BYTE types */
#define	CIFF_TC_ID_CANONUNK32	(CIFF_TC_DT_BYTE|0x0032) /* WB etc. */
#define	CIFF_TC_ID_CANONUNK36	(CIFF_TC_DT_BYTE|0x0036)

#define	CIFF_TC_ID_CANONRAW	(CIFF_TC_DT_BYTE2|0x0005)
#define	CIFF_TC_ID_CANONJPEG1	(CIFF_TC_DT_BYTE2|0x0007)
#define	CIFF_TC_ID_CANONJPEG2	(CIFF_TC_DT_BYTE2|0x0008)

/* ASCII types */
#define	CIFF_TC_ID_DESCRIPTION	(CIFF_TC_DT_ASCII|0x0005)
#define	CIFF_TC_ID_MODELNAME	(CIFF_TC_DT_ASCII|0x000a)
#define	CIFF_TC_ID_FIRMWARE	(CIFF_TC_DT_ASCII|0x000b)
#define	CIFF_TC_ID_COMPONENT	(CIFF_TC_DT_ASCII|0x000c)
#define	CIFF_TC_ID_ROMOPMODE	(CIFF_TC_DT_ASCII|0x000d)
#define	CIFF_TC_ID_OWNERNAME	(CIFF_TC_DT_ASCII|0x0010)
#define	CIFF_TC_ID_IMAGENAME	(CIFF_TC_DT_ASCII|0x0015)
#define	CIFF_TC_ID_IMAGEFILE	(CIFF_TC_DT_ASCII|0x0016)
#define	CIFF_TC_ID_THUMBNAIL	(CIFF_TC_DT_ASCII|0x0017)

/* WORD types */
#define	CIFF_TC_ID_TARGETIMG	(CIFF_TC_DT_WORD|0x000a)
#define	CIFF_TC_ID_SR_RELMETH	(CIFF_TC_DT_WORD|0x0010)
#define	CIFF_TC_ID_SR_RELTIME	(CIFF_TC_DT_WORD|0x0011)
#define	CIFF_TC_ID_RELEASE	(CIFF_TC_DT_WORD|0x0016)
#define	CIFF_TC_ID_BODYSENSE	(CIFF_TC_DT_WORD|0x001c)

#define	CIFF_TC_ID_CANONUNK28	(CIFF_TC_DT_WORD|0x0028)
#define	CIFF_TC_ID_CANONUNK29	(CIFF_TC_DT_WORD|0x0029)
#define	CIFF_TC_ID_CANONUNK2A	(CIFF_TC_DT_WORD|0x002a)
#define	CIFF_TC_ID_CANONUNK2C	(CIFF_TC_DT_WORD|0x002c)
#define	CIFF_TC_ID_CANONUNK2D	(CIFF_TC_DT_WORD|0x002d)
#define	CIFF_TC_ID_CANONUNK30	(CIFF_TC_DT_WORD|0x0030)
#define	CIFF_TC_ID_CANON_SENSOR	(CIFF_TC_DT_WORD|0x0031)
#define	CIFF_TC_ID_CANON_CFN	(CIFF_TC_DT_WORD|0x0033)

#define	CIFF_TC_ID_CANONUNKA8	(CIFF_TC_DT_WORD|0x00a8) /* D60 */
#define	CIFF_TC_ID_CANON_WB2	(CIFF_TC_DT_WORD|0x00a9) /* D60 WB */
#define	CIFF_TC_ID_CANONUNKAA	(CIFF_TC_DT_WORD|0x00aa) /* D60 */
#define	CIFF_TC_ID_CANONUNKC0	(CIFF_TC_DT_WORD|0x00c0) /* D60 */
#define	CIFF_TC_ID_CANONUNKC1	(CIFF_TC_DT_WORD|0x00c1) /* D60 */
#define	CIFF_TC_ID_CANONUNKC2	(CIFF_TC_DT_WORD|0x00c2) /* D60 */

/* DWORD types */
#define	CIFF_TC_ID_IMAGEFORMAT	(CIFF_TC_DT_DWORD|0x0003)
#define	CIFF_TC_ID_RECORDID	(CIFF_TC_DT_DWORD|0x0004)
#define	CIFF_TC_ID_SELFTIMER	(CIFF_TC_DT_DWORD|0x0006)
#define	CIFF_TC_ID_SR_TARGETDST	(CIFF_TC_DT_DWORD|0x0007)
#define	CIFF_TC_ID_BODYID	(CIFF_TC_DT_DWORD|0x000b)
#define	CIFF_TC_ID_CAPTURETIME	(CIFF_TC_DT_DWORD|0x000e)
#define	CIFF_TC_ID_IMAGESPEC	(CIFF_TC_DT_DWORD|0x0010)
#define	CIFF_TC_ID_SR_EF	(CIFF_TC_DT_DWORD|0x0013)
#define	CIFF_TC_ID_MI_EV	(CIFF_TC_DT_DWORD|0x0014)
#define	CIFF_TC_ID_SERIALNUMBER	(CIFF_TC_DT_DWORD|0x0017)
#define	CIFF_TC_ID_SR_EXPOSURE	(CIFF_TC_DT_DWORD|0x0018)

#define	CIFF_TC_ID_CANONUNK34	(CIFF_TC_DT_DWORD|0x0034)

#define	CIFF_TC_ID_CANONUNK7F	(CIFF_TC_DT_DWORD|0x007f) /* G2 */

/* from David Coffin's code */
#define	CIFF_TC_ID_DECODETABLE	(CIFF_TC_DT_DWORD|0x0035)

/* HEAP1 types */
#define	CIFF_TC_ID_IMAGEDESC	(CIFF_TC_DT_HEAP1|0x0004)
#define	CIFF_TC_ID_CAMERAOBJECT	(CIFF_TC_DT_HEAP1|0x0007)

/* HEAP2 types */
#define	CIFF_TC_ID_SHOOTINGREC	(CIFF_TC_DT_HEAP2|0x0002)
#define	CIFF_TC_ID_MEASUREDINFO	(CIFF_TC_DT_HEAP2|0x0003)
#define	CIFF_TC_ID_CAMERASPEC	(CIFF_TC_DT_HEAP2|0x0004)
#define	CIFF_TC_ID_IMAGEPROPS	(CIFF_TC_DT_HEAP2|0x000a)
#define	CIFF_TC_ID_CANONRAWPROPS	(CIFF_TC_DT_HEAP2|0x000b)

/* Canon Specific Values */

#define	CIFF_CANON_ISO_OFFSET		0x0004	/* in CIFF_TC_ID_CANONUNK2A */
#define	CIFF_CANON_ISO_100		160
#define	CIFF_CANON_ISO_200		192
#define	CIFF_CANON_ISO_400		224
#define	CIFF_CANON_ISO_800		256
#define	CIFF_CANON_ISO_1000		268
#define	CIFF_CANON_ISO_1600		288 /* XXX */

#define	CIFF_CANON_WB_OFFSET		0x000e	/* in CIFF_TC_ID_CANONUNK2A */
#define	CIFF_CANON_WB_AUTO		0
#define	CIFF_CANON_WB_DAYLIGHT		1
#define	CIFF_CANON_WB_CLOUDY		2
#define	CIFF_CANON_WB_TUNGSTEN		3
#define	CIFF_CANON_WB_FLOURESCENT	4
#define	CIFF_CANON_WB_FLASH		5
#define	CIFF_CANON_WB_PRESET		6

#define	CIFF_CANON_SUBJ_DIST		0x0028	/* in CIFF_TC_ID_CANONUNK2A */

int ciff_read_heap(struct raw *raw, struct ciff_heap *ptr);

u_int8_t raw_read_uint8(const struct raw *raw, int where);
int16_t raw_read_int16(const struct raw *raw, int where);
u_int16_t raw_read_uint16(const struct raw *raw, int where);
u_int32_t raw_read_uint32(const struct raw *raw, int where);
int32_t raw_read_sint32(const struct raw *raw, int where);
float raw_read_float32(const struct raw *raw, int where);
char *raw_read_ascii(const struct raw *raw, int where);
