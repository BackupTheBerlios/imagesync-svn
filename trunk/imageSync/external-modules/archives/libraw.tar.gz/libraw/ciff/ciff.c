/* $Id: ciff.c,v 1.13 2002/05/10 10:22:36 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Read a RAW file, identify it, build the right data structures
 */

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <err.h>
#include <sys/types.h>
#include <machine/endian.h>

#include <assert.h>

#include <raw.h>

const char tabs[] = "\t\t\t\t\t\t\t\t\t\t\t\t\t";
static int level = sizeof(tabs) + 1;
#define	TABS	(tabs + level - 1)

/* debug helpers */
void ciff_dump_ascii(const struct raw *, const struct ciff_heap *, const char *);
void ciff_dump_heap(const struct raw *, const struct ciff_heap *, const char *);
void ciff_dump_byte(const struct raw *, const struct ciff_heap *, const char *);
void ciff_dump_word(const struct raw *, const struct ciff_heap *, const char *);
void ciff_dump_dword(const struct raw *, const struct ciff_heap *, const char *);

/*
 */
int
ciff_read_heap(struct raw *raw, struct ciff_heap *heap)
{
	int fn, i, j;
	u_int16_t m, n;
	struct ciff_heap *ciff;
	int ot;
	u_int32_t a32, b32, c32;
	int len;
	int wb;

	struct sensor *sensor = &raw->sensor;

	assert(raw != NULL);
	assert(heap != NULL);

	level--;

	ot = raw_read_uint32(raw, heap->data + heap->size - 4) + heap->data;

	RDEBUG2(("%soffset table = 0x%08x\n", TABS, ot));

	n = raw_read_uint16(raw, ot);

	RDEBUG(("%snum records = %u\n", TABS, n));

#define REC(i) (ot + 2 + i * 10)

	if ((heap->next = calloc(sizeof(struct ciff_heap), 1)) == NULL) {
		warn("%s: malloc failed", __func__);
		level++;
		return 0;
	}

	ciff = heap->next;

	for (i = 0, ciff = heap->next; i < n; i++, ciff = ciff->next) {
		ciff->type = raw_read_uint16(raw, REC(i));

		if ((ciff->next = calloc(sizeof(struct ciff_heap), 1)) == NULL) {
			warn("%s: malloc failed", __func__);
			level++;
			return 0;
		}

		if ((ciff->type & CIFF_TC_ST_MASK) == CIFF_TC_ST_RECORD) {
			/* data is stored in the heap offset table itself */

			/*
			 * The CIFF spec allows for data longer than 8 bytes
			 * as long as the data contains its own delimiter or
			 * length indicator, but the spec does not say how
			 * the offsetTbl is then structured. Duh. Ignore,
			 * and hope everyone else does too.
			 */

			ciff->size = 8;
			ciff->data = REC(i) + 2;
			RDEBUG2(("%sHEAP entry type 0x%04hx\n",
				TABS, ciff->type));

		} else {
			/* data is external */
			ciff->size = raw_read_uint32(raw, REC(i) + 2);
			ciff->data = raw_read_uint32(raw, REC(i) + 6) + heap->data;

			RDEBUG2(("%sOTHER entry len 0x%x type 0x%04hx\n",
				TABS, ciff->size, ciff->type));
		}

		/* data record */
		switch (ciff->type & ~CIFF_TC_ST_MASK) {
		case CIFF_TC_ID_NULL:
			RDEBUG(("%sNULL record\n", TABS));
			break;

		case CIFF_TC_ID_FREE:
			RDEBUG(("%sFREE record\n", TABS));
			break;

		case CIFF_TC_ID_CANONRAW:
			raw->sensordata = ciff;
			RDEBUG(("%sCanon raw data len 0x%x\n", TABS, ciff->size));
			break;

		case CIFF_TC_ID_CANONJPEG1:
			raw->jpegthumbnail = ciff;
			RDEBUG(("%sCanon JPEG thumbnail type 1 len 0x%x\n", TABS, ciff->size));
			break;

		case CIFF_TC_ID_CANONJPEG2:
			raw->jpegthumbnail = ciff;
			RDEBUG(("%sCanon JPEG thumbnail type 2 len 0x%x\n", TABS, ciff->size));
			break;

/* ASCII types */
		case CIFF_TC_ID_DESCRIPTION:
			RDEBUG(("%sDescription '%s'\n", TABS, raw_read_ascii(raw, ciff->data)));
			break;

		case CIFF_TC_ID_MODELNAME:
			raw->manufacturer = raw_read_ascii(raw, ciff->data);
			raw->model = raw_read_ascii(raw, ciff->data + strlen(raw->manufacturer) + 1);
			RDEBUG(("%sManufacturer '%s' Model '%s'\n", TABS,
				raw->manufacturer, raw->model));
			break;

		case CIFF_TC_ID_FIRMWARE:
			raw->firmware = raw_read_ascii(raw, ciff->data);
			RDEBUG(("%sFirmware '%s'\n", TABS, raw->firmware));
			break;

		case CIFF_TC_ID_COMPONENT:
			raw->component = raw_read_ascii(raw, ciff->data);
			RDEBUG(("%sComponent '%s'\n", TABS, raw->component));
			break;

		case CIFF_TC_ID_ROMOPMODE:
			raw->romOpMode = raw_read_ascii(raw, ciff->data);
			RDEBUG(("%sROM Operation Mode '%s'\n", TABS, raw->romOpMode));
			break;

		case CIFF_TC_ID_OWNERNAME:
			raw->owner = raw_read_ascii(raw, ciff->data);
			RDEBUG(("%sOwner Name '%s'\n", TABS, raw->owner));
			break;

		case CIFF_TC_ID_IMAGEFILE:
			raw->imageFilename = raw_read_ascii(raw, ciff->data);
			RDEBUG(("%sImageFile '%s'\n", TABS, raw->imageFilename));
			break;

		case CIFF_TC_ID_THUMBNAIL:
			raw->thumbFilename = raw_read_ascii(raw, ciff->data);
			RDEBUG(("%sThumbNail '%s'\n", TABS, raw->thumbFilename));
			break;

/* WORD (16 bits alignment) types */

		case CIFF_TC_ID_TARGETIMG:
			raw->targetImagetype = raw_read_uint16(raw, ciff->data);
			RDEBUG(("%sImage Type %hu\n", TABS, raw->targetImagetype));
			break;

		case CIFF_TC_ID_SR_RELMETH:
			raw->releaseMethod = raw_read_uint16(raw, ciff->data);
			RDEBUG(("%sRelease Method %u\n", TABS, raw->releaseMethod));	
			break;

		case CIFF_TC_ID_SR_RELTIME:
			raw->releaseTiming = raw_read_uint16(raw, ciff->data);
			RDEBUG(("%sRelease Timing %u\n", TABS, raw->releaseTiming));	
			break;

		case CIFF_TC_ID_RELEASE:
			raw->releaseSetting = raw_read_uint16(raw, ciff->data);
			RDEBUG(("%sRelease Setting %u\n", TABS, raw->releaseSetting));	
			break;


		case CIFF_TC_ID_BODYSENSE:
			raw->bodysensitivity = raw_read_uint16(raw, ciff->data);
			RDEBUG(("%sBody Sensitivity %hu\n", TABS, raw->bodysensitivity));	
			break;

		case CIFF_TC_ID_CANON_SENSOR:
			sensor->width	= raw_read_uint16(raw, ciff->data + 2);
			sensor->height	= raw_read_uint16(raw, ciff->data + 4);
			sensor->x_offset= raw_read_uint16(raw, ciff->data + 10);
			sensor->y_offset= raw_read_uint16(raw, ciff->data + 12);
			sensor->x_out	= raw_read_uint16(raw, ciff->data + 14) -
						  sensor->x_offset + 1;
			sensor->y_out	= raw_read_uint16(raw, ciff->data + 16) -
						  sensor->y_offset + 1;

			RDEBUG(("%sSensor: %d x %d from %d, %d -> %d x %d\n", TABS,
				sensor->width, sensor->height, sensor->x_offset,
				sensor->y_offset, sensor->x_out, sensor->y_out));
			break;

		case CIFF_TC_ID_CANON_WB2:
			RDEBUG(("%sWhite Balance (Type 2) Data\n", TABS));	
			len = raw_read_uint16(raw, ciff->data);
			wb = (len - sizeof(u_int16_t)) / (4 * sizeof(u_int16_t));
			RDEBUG(("%d values in %d bytes\n", wb, len));
			for (n = 0; n < wb; n++) {
				sensor->wb[n][0] = raw_read_uint16(raw, ciff->data + 2 + n * 8);
				sensor->wb[n][1] = raw_read_uint16(raw, ciff->data + 4 + n * 8);
				sensor->wb[n][2] = raw_read_uint16(raw, ciff->data + 6 + n * 8);
				sensor->wb[n][3] = raw_read_uint16(raw, ciff->data + 8 + n * 8);
			}
			RDEBUG(("\n"));
			break;

/* DWORD (32 bit alignment) types */
		case CIFF_TC_ID_IMAGEFORMAT:
			a32 = raw_read_uint32(raw, ciff->data);
			raw->fileFormat = a32 >> 16;
			raw->compressionType = a32 & 0xffff;
			raw->targetCompression = raw_read_float32(raw, ciff->data + 4);
			RDEBUG(("%sImage Format: %u, %u, %f\n", TABS, raw->fileFormat,
				raw->compressionType, raw->targetCompression));
			break;

		case CIFF_TC_ID_RECORDID:
			raw->recordID = raw_read_uint32(raw, ciff->data);
			RDEBUG(("%sRecord ID = %u\n",
				TABS, raw->recordID));
			break;

		case CIFF_TC_ID_SELFTIMER:
			/* XXX */
			RDEBUG(("%sSelf Timer Time = %u, %u\n",
				TABS, raw_read_uint32(raw, ciff->data),
				raw_read_uint32(raw, ciff->data + 4)));
			break;

		case CIFF_TC_ID_SR_TARGETDST:
			raw->targetDistance = raw_read_float32(raw, ciff->data);
			RDEBUG(("%sTarget Distance = %f\n",
				TABS, raw->targetDistance));
			break;

		case CIFF_TC_ID_BODYID:
			raw->bodyid = raw_read_uint32(raw, ciff->data);
			RDEBUG(("%sBody ID = %u\n",
				TABS, raw->bodyid));
			break;

		case CIFF_TC_ID_CAPTURETIME:
			raw->captureTimeCount = raw_read_uint32(raw, ciff->data);
			raw->captureTimeZoneCode = raw_read_sint32(raw, ciff->data + 4);
			raw->captureTimeZoneInfo = raw_read_uint32(raw, ciff->data + 4);

			RDEBUG(("%sCapture Time = %u, %d, %u\n",
				TABS, raw->captureTimeCount,
				raw->captureTimeZoneCode, raw->captureTimeZoneInfo));
			break;

		case CIFF_TC_ID_IMAGESPEC:
			raw->imageWidth		= raw_read_uint32(raw, ciff->data);
			raw->imageHeight	= raw_read_uint32(raw, ciff->data + 4);
			raw->pixelAspectRatio	= raw_read_float32(raw, ciff->data + 8);
			raw->rotationAngle	= raw_read_sint32(raw, ciff->data + 12);
			raw->componentBitDepth	= raw_read_uint32(raw, ciff->data + 16);
			raw->colorBitDepth	= raw_read_uint32(raw, ciff->data + 20);
			raw->colorBW		= raw_read_uint32(raw, ciff->data + 24);
			
			RDEBUG(("%sImage Specification [%u x %u]"
				" aspect %f, angle %d. %u, %u, %u\n",
				TABS, raw->imageWidth, raw->imageHeight,
				raw->pixelAspectRatio, raw->rotationAngle,
				raw->componentBitDepth, raw->colorBitDepth,
				raw->colorBW
				));
			break;
		case CIFF_TC_ID_SR_EF:
			raw->efGuideNumber = raw_read_float32(raw, ciff->data);
			raw->efThreshold = raw_read_float32(raw, ciff->data + 4);
			RDEBUG(("%sSR EF Guide = %f, Threshold = %f\n",
				TABS, raw->efGuideNumber, raw->efThreshold));
			break;
		case CIFF_TC_ID_MI_EV:
			raw->ev = raw_read_float32(raw, ciff->data);
			RDEBUG(("%sMeasured EV = %f\n",
				TABS, raw->ev));
			break;
		case CIFF_TC_ID_SERIALNUMBER:
			raw->serialNumber = raw_read_uint32(raw, ciff->data);
			RDEBUG(("%sSerial Number = %u\n",
				TABS, raw->serialNumber));
			break;
		case CIFF_TC_ID_SR_EXPOSURE:
			raw->exposureCompensation = raw_read_float32(raw, ciff->data);
			raw->tv = raw_read_float32(raw, ciff->data + 4);
			raw->av = raw_read_float32(raw, ciff->data + 8);
			RDEBUG(("%sSR exposureCompensation = %f, tv = %f, av = %f\n",
				TABS, raw->exposureCompensation, raw->tv, raw->av));
			break;

		case CIFF_TC_ID_DECODETABLE:
			raw->decodeTable = raw_read_uint32(raw, ciff->data);
			a32 = raw_read_uint32(raw, ciff->data + 4);
			b32 = raw_read_uint32(raw, ciff->data + 8);
			c32 = raw_read_uint32(raw, ciff->data + 12);
			RDEBUG(("%sDecode Table (len 0x%x) %u %u %u %u\n",
				TABS, ciff->size, raw->decodeTable,
				a32, b32, c32));

			break;

/* HEAP1 types */
		case CIFF_TC_ID_CAMERAOBJECT:
			RDEBUG(("%sHEAP: CameraObject (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));

			ciff_read_heap(raw, ciff);
			break;

		case CIFF_TC_ID_IMAGEDESC:
			RDEBUG(("%sHEAP: ImageDescription (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));

/* HEAP2 types */
		case CIFF_TC_ID_SHOOTINGREC:
			RDEBUG(("%sHEAP: ShootingRecord (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));
			ciff_read_heap(raw, ciff);
			break;

		case CIFF_TC_ID_MEASUREDINFO:
			RDEBUG(("%sHEAP: MeasuredInfo (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));
			ciff_read_heap(raw, ciff);
			break;

		case CIFF_TC_ID_CAMERASPEC:
			RDEBUG(("%sHEAP: CameraSpec (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));
			ciff_read_heap(raw, ciff);
			break;

		case CIFF_TC_ID_IMAGEPROPS:
			RDEBUG(("%sHEAP: ImageProps (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));
			ciff_read_heap(raw, ciff);
			break;

		case CIFF_TC_ID_CANONRAWPROPS:
			RDEBUG(("%sHEAP: CanonRaWProps (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));
			ciff_read_heap(raw, ciff);
			break;

/* others */

		case CIFF_TC_ID_CANONUNK36:
			RDEBUG(("%sBYTES: CanonUnknown36 (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));
			ciff_dump_byte(raw, ciff, TABS);
			raw->temp = ciff;
			break;

		case CIFF_TC_ID_CANONUNK2A:
			RDEBUG(("%sBYTES: CanonShotInfo (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK,
				ciff->size));
			ciff_dump_word(raw, ciff, TABS);
			break;

		case CIFF_TC_ID_CANON_CFN:
			RDEBUG(("%sCanonCustomFunctions (0x%04hx) len 0x%x\n",
				TABS, ciff->type & ~CIFF_TC_ST_MASK, ciff->size));
			fn = raw_read_uint16(raw, ciff->data) / 2 - 1;
			level--;
			for (j = 0; j < fn; j++) {
				m = raw_read_uint16(raw, ciff->data + j*2 + 2);
				RDEBUG(("%sCFn %02d = %d\n", TABS, m >> 8, m & 0xff));
			}
			level++;
	
			break;
			


#ifndef min
#define min(a, b) ((a < b) ? a : b)
#endif
		/* undefined types */
		default:
			switch (ciff->type & CIFF_TC_DT_MASK) {
			case CIFF_TC_DT_ASCII:
				ciff_dump_ascii(raw, ciff, TABS);
				break;

			case CIFF_TC_DT_HEAP1:
			case CIFF_TC_DT_HEAP2:
				ciff_dump_heap(raw, ciff, TABS);
				ciff_read_heap(raw, ciff);
				break;

			case CIFF_TC_DT_BYTE:
				RDEBUG(("%sUNKNOWN BYTE type 0x%04hx len 0x%x\n", TABS, ciff->type, ciff->size));

				ciff_dump_byte(raw, ciff, TABS);
				break;

			case CIFF_TC_DT_WORD:
				RDEBUG(("%sUNKNOWN WORD type 0x%04hx len 0x%x\n", TABS, ciff->type, ciff->size));
				ciff_dump_word(raw, ciff, TABS);
				break;

			case CIFF_TC_DT_DWORD:
				RDEBUG(("%sUNKNOWN DWORD type 0x%04hx len 0x%x\n", TABS, ciff->type, ciff->size));
				ciff_dump_dword(raw, ciff, TABS);
				break;

			default:
				RDEBUG(("%sUNKNOWN type 0x%04hx len 0x%x\n",
				       TABS, ciff->type, ciff->size));

				break;
			}

		}
	}

	free(ciff->next);
	ciff->next = NULL;

	level++;
	return 1;
}

void
ciff_dump_ascii(const struct raw *raw, const struct ciff_heap *ciff, const char *tabs)
{
	RDEBUG(("%sASCII: UNKNOWN (0x%04hx) len 0x%x [%s]\n",
		tabs, ciff->type, ciff->size, raw_read_ascii(raw, ciff->data)));

}

void
ciff_dump_heap(const struct raw *raw, const struct ciff_heap *ciff, const char *tabs)
{
	RDEBUG(("%sHEAP: UNKNOWN (0x%04hx) len 0x%x\n",
		tabs, ciff->type & ~CIFF_TC_ST_MASK, ciff->size));
}

void
ciff_dump_byte(const struct raw *raw, const struct ciff_heap *ciff, const char *tabs)
{
	int j, k;
	u_int8_t a8;

	for (k = 0; k < ciff->size; k += 8) {
		RDEBUG(("%s%06x\t", tabs + 1, k));
		for (j = 0; j < min(ciff->size - k, 8); j++) {
			a8 = raw_read_uint8(raw, ciff->data + k + j);
			RDEBUG(("%02x ", a8));
		}

		RDEBUG(("\t"));
		for (j = 0; j < min(ciff->size - k, 8); j++) {
			a8 = raw_read_uint8(raw, ciff->data + k + j);
			RDEBUG(("%c ", isprint(a8) ? a8 : '.'));
		}
		RDEBUG(("\n"));
	}
}

void
ciff_dump_word(const struct raw *raw, const struct ciff_heap *ciff, const char *tabs)
{
	int j, k;
	int16_t a16;
	
	for (k = 0; k < ciff->size; k += 8) {
		RDEBUG(("%s%06x\t", tabs + 1, k));
		for (j = 0; j < min(ciff->size - k, 8); j += 2) {
			a16 = raw_read_int16(raw, ciff->data + k + j);
			RDEBUG(("%04x(%-6d) ", (u_int16_t) a16, a16));
		}

		RDEBUG(("\n"));
	}
}

void
ciff_dump_dword(const struct raw *raw, const struct ciff_heap *ciff, const char *tabs)
{
	int j, k;
	u_int32_t a32;
	float f32;

	a32 = raw_read_uint32(raw, ciff->data);
	for (k = 0; k < ciff->size; k += 8) {
		RDEBUG(("%s%06x\t", tabs + 1, k));
		for (j = 0; j < min(ciff->size, 8); j += 4) {
			a32 = raw_read_uint32(raw, ciff->data + k + j);
			f32 = raw_read_float32(raw, ciff->data + k + j);
			RDEBUG(("%08x(%10d / %f) ",
				a32, a32, f32));
		}

		RDEBUG(("\n"));
	}
}
