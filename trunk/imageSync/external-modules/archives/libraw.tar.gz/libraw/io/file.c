/* $Id: file.c,v 1.5 2002/05/10 10:22:36 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Read a RAW file, identify it, build the right data structures
 */

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>
#include <sys/types.h>
#ifdef HAVE_MMAP
#include <sys/mman.h>
#endif
#include <sys/stat.h>
#include <machine/endian.h>

#include <raw.h>

struct raw *
open_raw(const char *filename)
{
	struct raw *raw;
	char *data;
	int fd;

	if ((raw = (struct raw *) calloc(1, sizeof(struct raw))) == NULL) {
		warn("open_raw: malloc failed");
		return NULL;
	}

	/* raw->sensor = calloc(sizeof(struct sensor), 1); */

	if ((fd = open(filename, O_RDONLY)) < 0) {
		warn("open_raw: cannot open %s", filename);
		free(raw);
		return NULL;
	}

#if DEBUG > 1
	printf("open_raw: file %s opened for reading on descriptor %d\n",
	       filename, fd);
#endif

	if (fstat(fd, &raw->st) == -1) {
		warn("open_raw: fstat failed");
		free(raw);
		close(fd);
		return(NULL);
	}

#if DEBUG > 1
	printf("open_raw: file %s is 0x%08llx bytes long\n", filename, raw->st.st_size);
#endif

	if (raw->st.st_size < 100000) {
		warn("open_raw: file size seems too small");
		free(raw);
		close(fd);
		return(NULL);
	}

	/*
	 * map or read the file data into memory and make raw->data point
	 * to it.
	 */

#ifdef HAVE_MMAP

	if ((raw->data = mmap(NULL, raw->st.st_size, PROT_READ, 0, fd, 0)) == NULL) {
		warn("open_raw: mmap failed");
		free(raw);
		close(fd);
		return(NULL);
	}
	
#else

	if ((raw->data = malloc(raw->st.st_size)) == NULL) {
		warn("open_raw: malloc failed");
		free(raw);
		close(fd);
		return(NULL);
	}

	if (read(fd, raw->data, raw->st.st_size) < raw->st.st_size) {
		warn("open_raw: read failed");
		free(raw->data);
		free(raw);
		close(fd);
		return(NULL);
	}

#endif

	/* done with file */
	close(fd);

	/* identify supported file types */

	data = (char *) raw->data;

	if (strncmp(data + 6, "HEAPCCDR", 8) == 0) {
		/* this is a CIFF */

#if DEBUG
		printf("open_raw: CIFF file found\n");
#endif

		raw->type = RAW_TYPE_CANON;

		/* check Intel or Motorola endianness */
		if (data[0] == 'I' && data[1] == 'I') {
			raw->endian = RAW_ENDIAN_LE;
		} else {
			raw->endian = RAW_ENDIAN_BE;
		}
#if DEBUG > 1
		printf("open_raw: data is %s endian\n",
		       raw->endian == RAW_ENDIAN_BE ? "big" : "little");
#endif

		if ((raw->ciff = malloc(sizeof(struct ciff_heap))) == NULL) {
			warn("open_raw: malloc ciff_heap failed");
			return NULL;
		}

		raw->ciff->size = raw->st.st_size - CIFF_HEADER_SIZE;
		raw->ciff->data = CIFF_HEADER_SIZE;
		raw->ciff->type = CIFF_TC_DT_HEAP1;

		ciff_read_heap(raw, raw->ciff);

	} else {
		/* UNKNOWN */
		raw->type = RAW_TYPE_UNKNOWN;
		close_raw(raw);
		return NULL;
	}

	return raw;
}

void
close_raw(struct raw *raw)
{
#ifdef HAVE_MMAP
	munmap(raw->data, raw->st.st_size);
#else
	free(raw->data);
#endif
	free(raw);
}
