/* $Id: canon_d60.c,v 1.3 2002/05/10 10:22:35 peter Exp $ */

/*
 * Copyright (c) 2002 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <raw.h>

/*
 * The D60 creates 12 bits per sensor element, but only compresses the
 * upper 10 of them using the common Canon algorithm. The lower 2 bits
 * of each sensor sample is stored uncompressed at the beginning of
 * the data heap. We decode the normal 10 bits then shift and merge
 * the lower 2 bits
 */
int
canon_decode_d60(struct raw *raw)
{
	int p, i, off;
	u_int8_t s, *data = raw->data + raw->sensordata->data;

	raw->encodedarray = data +
			    (raw->sensor.width * raw->sensor.height) / 4 +
			    514;

	canon_decode(raw);
	
	for (p = 0; p < raw->sensor.height * raw->sensor.width; p += 4) {
		s = *(data + p / 4);

		for (i = 0; i < 4; i++) {
			off = p + i;
			*(raw->sensorarray + off) <<= 2;
			*(raw->sensorarray + off) |= (s>>(i*2))&3;
		}
	}


	raw->sensor.cfa = RAW_CFA_RGGB;

	return 1;
}

