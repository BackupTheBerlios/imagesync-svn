/* $Id: camera.c,v 1.1 2001/11/01 14:34:29 peter Exp $ */
/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <raw.h>

#define	WB_HEADROOM	4

/*
 * apply white balance to raw RGB
 */
int
camera_wb(struct raw *raw, cameraWB wb)
{
	int i, min_wb, max_wb, scale;
	struct camera_wb cwb;
	u_int64_t r, g, b;

	/* find the selected WB struct */
	for (i = 0; raw->camera->wb[i].wb != END; i++) {
		if (raw->camera->wb[i].wb == wb)
			break;
	}

	if (raw->camera->wb[i].wb == END)
		return 0;

	cwb = raw->camera->wb[i];

	min_wb = min(cwb.red, min(cwb.green, cwb.blue));
	max_wb = max(cwb.red, max(cwb.green, cwb.blue));
	scale = (min_wb << WB_HEADROOM) / max_wb;

	if (scale > (1 << WB_HEADROOM))
		return 0;

	for (i = 0; i < raw->rawrgb_x * raw->rawrgb_y; i++) {
		r = *(raw->rawrgb_r + i);
		g = *(raw->rawrgb_g + i);
		b = *(raw->rawrgb_b + i);

		RDEBUG2(("%lld, %lld, %lld -> ", r, g, b));

		r = ((r * scale) * max_wb) / cwb.red;
		g = ((g * scale) * max_wb) / cwb.green;
		b = ((b * scale) * max_wb) / cwb.blue;

		RDEBUG2(("%lld, %lld, %lld\n", r, g, b));

		*(raw->rawrgb_r + i) = r;
		*(raw->rawrgb_g + i) = g;
		*(raw->rawrgb_b + i) = b;
	}

	return 1;
}
