/* $Id: raw.h,v 1.12 2002/05/10 10:22:35 peter Exp $ */

/*
 * Copyright (c) 2001,2002 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * RAW files format library header file
 */
#include <sys/types.h>
#include <sys/stat.h>

struct raw;

typedef enum {
	WB_AUTO,
	WB_DAYLIGHT,
	WB_CLOUDY,
	WB_TUNGSTEN,
	WB_FLUORESCENT,
	WB_FLASH,
	WB_PRESET,
	WB_OTHER1,
	WB_OTHER2,
	WB_END,
} cameraWB;

/*
 * struct sensor contains a description of the physical characteristics of
 * the sensor and the sensitivities of the individual elements.
 *
 * While not completely correct, white balance information for each sensor
 * is also stored here as it can be considered a characteristic of the
 * sensor.
 */
struct sensor {
	int		width;
	int		height;
	int		x_offset;
	int		y_offset;
	int		x_out;
	int		y_out;
	u_int16_t	wb[WB_END][4];

	int		cfa;		/* CFA Layout */

#define RAW_CFA_RGGB		1	/* R-G-R-G ... G-B-G-B */
	
};


#define	SENSORELEMENT_T	int16_t
#define	COLOURDEPTH_T	u_int16_t

/*
 * struct raw is the container for all the properties and data of
 * a raw file.
 *
 * I expect it to be very focused on Canon CRW format since that
 * is the primary reason for the development of this library.
 * Additional work to incorporate support for other raw formats
 * will need to carefully alter this structure in a backward
 * compatible manner for additional or different requirements of
 * other makers raw formats (NEF etc.)
 */
struct raw {
	int		type;		/* Raw file type */

#define	RAW_TYPE_UNKNOWN	0x0000
#define RAW_TYPE_CANON		0x1000

	int		subtype;	/* Raw file subtype */

#define RAW_TYPE_CANON_D30	0x1001
#define RAW_TYPE_CANON_D60	0x1002

	struct sensor	sensor;		/* sensor related information,
					   size, white balance etc. */
	u_int8_t	*encodedarray;
	SENSORELEMENT_T	*sensorarray;	/* 'decoded' sensor data array */

	u_int16_t	*rawrgb_r;
	u_int16_t	*rawrgb_g;
	u_int16_t	*rawrgb_b;

	u_int32_t	rawrgb_x;
	u_int32_t	rawrgb_y;
	u_int32_t	rawrgb_d;

	int		endian;		/* Intel or Motorola */

#define RAW_ENDIAN_BE		0
#define RAW_ENDIAN_LE		1

	void		*data;		/* raw (file) data in memory */
	struct stat	st;		/* store file stat for reuse */

	struct ciff_heap *ciff;

	/* special heap structures worth keeping explicit pointers to */
	struct ciff_heap	*sensordata;
	struct ciff_heap	*jpegthumbnail;

	struct ciff_heap	*temp;

	/* other processed CIFF data */

	/* Image Format */
	u_int16_t		fileFormat;
	u_int16_t		compressionType;
	float			targetCompression;

	/* Image Spec */
	u_int32_t		imageWidth;
	u_int32_t		imageHeight;
	float			pixelAspectRatio;
	int32_t			rotationAngle;
	u_int32_t		componentBitDepth;
	u_int32_t		colorBitDepth;
	u_int32_t		colorBW;

	char			*manufacturer;
	char			*model;
	char			*owner;
	char			*firmware;
	char			*component;
	char			*romOpMode;

	char			*imageFilename;
	char			*thumbFilename;

	u_int32_t		bodyid;
	u_int32_t		recordID;

	u_int32_t		decodeTable;

	u_int16_t		targetImagetype;
	u_int16_t		releaseMethod;
	u_int16_t		releaseTiming;
	u_int16_t		releaseSetting;
	u_int16_t		bodysensitivity;

	u_int32_t		serialNumber;

	float			targetDistance;

	float			efGuideNumber;
	float			efThreshold;

	float			exposureCompensation;
	float			tv;	/* shutter value */
	float			av;	/* aperture value */

	float			ev;	/* luminance value */

	u_int32_t		captureTimeCount;
	int32_t			captureTimeZoneCode;
	u_int32_t		captureTimeZoneInfo;

};

#ifndef DEBUG
#define DEBUG 0
#endif

#define RDEBUG(x) if (DEBUG > 0) { printf x; }
#define RDEBUG2(x) if (DEBUG > 1) { printf x; }

#ifndef max
#define max(a, b) (a < b ? b : a)
#endif

#ifndef min
#define min(a, b) (a > b ? b : a)
#endif

#include <camera/camera.h>
#include <ciff/ciff.h>
#include <cfa/cfa.h>
#include <io/io.h>
