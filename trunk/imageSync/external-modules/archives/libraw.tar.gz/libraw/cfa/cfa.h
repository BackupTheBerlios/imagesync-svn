/* $Id: cfa.h,v 1.7 2002/05/09 19:59:55 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


int cfa_demosaick(struct raw *raw, int algorithm, int x_offset, int y_offset,
		  int x_out, int y_out);

/* Chang, Cheung, Pan; Variable Number of Gradients Method */
#define	CFA_ALG_CCP	1
int cfa_demosaick_ccp(struct raw *raw, int x_offset, int y_offset);

/* Simple nearest neighbour averaging method - Chris Breeze */
#define CFA_ALG_NEAREST_NEIGHBOUR 2
int cfa_demosaick_nearest_neighbour(struct raw *raw, int x_offset, int y_offset);

int cfa_wb(struct raw *raw, int algorithm, cameraWB wb);
void cfa_subtract_black(struct raw *raw, const u_int16_t x_offset, const u_int16_t y_offset);
