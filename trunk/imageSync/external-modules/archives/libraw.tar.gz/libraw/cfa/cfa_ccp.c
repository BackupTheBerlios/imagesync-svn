/* $Id: cfa_ccp.c,v 1.16 2002/05/10 10:22:35 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Demosaick a CFA using the Chang, Cheung and Pan algorithm described in
 * the paper "".
 */

#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <sys/types.h>

#include <raw.h>

struct cfa_cpp_scan {
	int8_t	x1;
	int8_t	y1;
	int8_t	x2;
	int8_t	y2;
	int8_t	d;		/* shift / divisor */
				/* 0 = no shift, -1 = no result */
};

#define	CFA_DIRECTIONS	8	/* N, NE, E, etc. */
#define	CFA_DIFFS	6	/* differences */

static const struct cfa_cpp_scan red_blue_scan[CFA_DIRECTIONS][CFA_DIFFS] = {
	/* north	eq. 13 - checked OK */
	{
		{  0, -1,  0, +1,  0 },
		{  0, -2,  0,  0,  0 },
		{ -1, -1, -1, +1,  1 },
		{ +1, -1, +1, +1,  1 },
		{ -1, -2, -1,  0,  1 },
		{ +1, -2, +1,  0,  1 }
	},

	/* north east	eq. 17 - checked OK */
	{
		{ +1, -1, -1, +1,  0 },
		{ +2, -2,  0,  0,  0 },
		{  0, -1, -1,  0,  1 },
		{ +1,  0,  0, +1,  1 },
		{ +1, -2,  0, -1,  1 },
		{ +2, -1, +1,  0,  1 }
	},

	/* east		eq. 14 - checked OK */
	{
		{ +1,  0, -1,  0,  0 },
		{ +2,  0,  0,  0,  0 },
		{ +1, -1, -1, -1,  1 },
		{ +1, +1, -1, +1,  1 },
		{ +2, -1,  0, -1,  1 },
		{ +2, +1,  0, +1,  1 }
	},

	/* south east	eq. 18 - checked OK */
	{
		{ +1, +1, -1, -1,  0 },
		{ +2, +2,  0,  0,  0 },
		{ +1,  0,  0, -1,  1 },
		{  0, +1, -1,  0,  1 },
		{ +2, +1, +1,  0,  1 },
		{ +1, +2,  0, +1,  1 }
	},

	/* south	eq. 15 - checked OK */
	{
		{  0, +1,  0, -1,  0 },
		{  0, +2,  0,  0,  0 },
		{ -1, +1, -1, -1,  1 },
		{ +1, +1, +1, -1,  1 },
		{ -1, +2, -1,  0,  1 },
		{ +1, +2, +1,  0,  1 }
	},

	/* south west	eq. 20 - checked OK */
	{
		{ -1, +1, +1, -1,  0 },
		{ -2, +2,  0,  0,  0 },
		{ -1,  0,  0, -1,  1 },
		{  0, +1, +1,  0,  1 },
		{ -2, +1, -1,  0,  1 },
		{ -1, +2,  0, +1,  1 }
	},

	/* west		eq. 16 - checked OK */
	{
		{ -1,  0, +1,  0,  0 },
		{ -2,  0,  0,  0,  0 },
		{ -1, -1, +1, -1,  1 },
		{ -1, +1, +1, +1,  1 },
		{ -2, -1,  0, -1,  1 },
		{ -2, +1,  0, +1,  1 }
	},

	/* north west	eq. 19 - checked OK */
	{
		{ -1, -1, +1, +1,  0 },
		{ -2, -2,  0,  0,  0 },
		{  0, -1, +1,  0,  1 },
		{ -1,  0,  0, +1,  1 },
		{ -1, -2,  0, -1,  1 },
		{ -2, -1, -1,  0,  1 }
	},

};

static const struct cfa_cpp_scan green_scan[CFA_DIRECTIONS][CFA_DIFFS] = {
	/* north	eq. 1 - checked OK */
	{
		{  0, -2,  0,  0,  0 },
		{  0, -1,  0, +1,  0 },
		{ -1, -1, -1, +1,  1 },
		{ +1, -1, +1, +1,  1 },
		{ -1,  0, -1, -2,  1 },
		{ +1,  0, +1, -2,  1 },
	},

	/* north east	eq. 5 - checked OK */
	{
		{ +1, -1, -1, +1,  0 },
		{ +2, -2,  0,  0,  0 },
		{ +1, -2, -1,  0,  0 },
		{ +2, -1,  0, +1,  0 },
		{  0,  0,  0,  0, -1 },
		{  0,  0,  0,  0, -1 },
	},

	/* east		eq. 2 - checked OK */
	{
		{ +1,  0, -1,  0,  0 },
		{ +2,  0,  0,  0,  0 },
		{ +1, -1, -1, -1,  1 },
		{ +1, +1, -1, +1,  1 },
		{ +2, -1,  0, -1,  1 },
		{ +2, +1,  0, +1,  1 },
	},

	/* south east	eq. 6 - checked OK */
	{
		{ +1, +1, -1, -1,  0 },
		{ +2, +2,  0,  0,  0 },
		{ +1, +2, -1,  0,  0 },
		{ +2, +1,  0, -1,  0 },
		{  0,  0,  0,  0, -1 },
		{  0,  0,  0,  0, -1 },
	},

	/* south	eq. 3 - checked OK */
	{
		{  0, +1,  0, -1,  0 },
		{  0, +2,  0,  0,  0 },
		{ +1, +1, +1, -1,  1 },
		{ -1, +1, -1, -1,  1 },
		{ +1, +2, +1,  0,  1 },
		{ -1, +2, -1,  0,  1 },
	},

	/* south west	eq. 8 - checked OK */
	{
		{ -1, +1, +1, -1,  0 },
		{ -2, +2,  0,  0,  0 },
		{ -1, +2, +1,  0,  0 },
		{ -2, +1,  0, -1,  0 },
		{  0,  0,  0,  0, -1 },
		{  0,  0,  0,  0, -1 },
	},

	/* west		eq. 4 - checked OK */
	{
		{ -1,  0, +1,  0,  0 },
		{ -2,  0,  0,  0,  0 },
		{ -1, +1, +1, +1,  1 },
		{ -1, -1, +1, -1,  1 },
		{ -2, +1,  0, +1,  1 },
		{ -2, -1,  0, -1,  1 },
	},

	/* north west	eq. 7 - checked OK */
	{
		{ -1, -1, +1, +1,  0 },
		{ -2, -2,  0,  0,  0 },
		{ -1, -2, +1,  0,  0 },
		{ -2, -1,  0, +1,  0 },
		{  0,  0,  0,  0, -1 },
		{  0,  0,  0,  0, -1 },
	},
	
};


#define	CFA_RED		0	/* red sensors */
#define	CFA_BLUE	1	/* blue sensors */
#define	CFA_GREEN_BLUE	2	/* green-on-blue row */
#define	CFA_GREEN_RED	3	/* green-on-red row */

			/* RGGB / RGB / NSEW etc. /  */
static int8_t rgb_average[4][3][CFA_DIRECTIONS][9] = {
	/* red centre [CFA_RED] */
	{
		{
			/* red pixel - checked OK */
			{ 2,  0,  0,  0, -2,  0,  0,  0,  0 }, /* north */
			{ 2,  0,  0, +2, -2,  0,  0,  0,  0 }, /* north east */
			{ 2,  0,  0, +2,  0,  0,  0,  0,  0 }, /* east */
			{ 2,  0,  0, +2, +2,  0,  0,  0,  0 }, /* south east */
			{ 2,  0,  0,  0, +2,  0,  0,  0,  0 }, /* south */
			{ 2,  0,  0, -2, +2,  0,  0,  0,  0 }, /* south west */
			{ 2,  0,  0, -2,  0,  0,  0,  0,  0 }, /* west */
			{ 2,  0,  0, -2, -2,  0,  0,  0,  0 }  /* north west */
		},

		{
			/* green pixel */
			{ 1,  0, -1,  0,  0,  0,  0,  0,  0 }, /* north */
			{ 4, +1,  0,  0, -1, +2, -1, +1, -2 }, /* north east */
			{ 1, +1,  0,  0,  0,  0,  0,  0,  0 }, /* east */
			{ 4, +1,  0,  0, +1, +2, +1, +1, +2 }, /* south east */
			{ 1,  0, +1,  0,  0,  0,  0,  0,  0 }, /* south */
			{ 4, -1,  0,  0, +1, -2, +1, -1, +2 }, /* south west */
			{ 1, -1,  0,  0,  0,  0,  0,  0,  0 }, /* west */
			{ 4, -1,  0,  0, -1, -2, -1, -1, -2 }  /* north west */
		},

		{
			/* blue pixel */
			{ 2, +1, -1, -1, -1,  0,  0,  0,  0 }, /* north */
			{ 1, +1, -1,  0,  0,  0,  0,  0,  0 }, /* north east */
			{ 2, +1, -1, +1, +1,  0,  0,  0,  0 }, /* east */
			{ 1, +1, +1,  0,  0,  0,  0,  0,  0 }, /* south east */
			{ 2, +1, +1, -1, +1,  0,  0,  0,  0 }, /* south */
			{ 1, -1, +1,  0,  0,  0,  0,  0,  0 }, /* south west */
			{ 2, -1, +1, -1, -1,  0,  0,  0,  0 }, /* west */
			{ 1, -1, -1,  0,  0,  0,  0,  0,  0 }  /* north west */
		},
	},

	/* blue centre [CFA_BLUE] */
	{

		{
			/* red pixel */
			{ 2, +1, -1, -1, -1,  0,  0,  0,  0 }, /* north */
			{ 1, +1, -1,  0,  0,  0,  0,  0,  0 }, /* north east */
			{ 2, +1, -1, +1, +1,  0,  0,  0,  0 }, /* east */
			{ 1, +1, +1,  0,  0,  0,  0,  0,  0 }, /* south east */
			{ 2, +1, +1, -1, +1,  0,  0,  0,  0 }, /* south */
			{ 1, -1, +1,  0,  0,  0,  0,  0,  0 }, /* south west */
			{ 2, -1, +1, -1, -1,  0,  0,  0,  0 }, /* west */
			{ 1, -1, -1,  0,  0,  0,  0,  0,  0 }  /* north west */
		},

		{
			/* green pixel */
			{ 1,  0, -1,  0,  0,  0,  0,  0,  0 }, /* north */
			{ 4, +1,  0,  0, -1, +2, -1, +1, -2 }, /* north east */
			{ 1, +1,  0,  0,  0,  0,  0,  0,  0 }, /* east */
			{ 4, +1,  0,  0, +1, +2, +1, +1, +2 }, /* south east */
			{ 1,  0, +1,  0,  0,  0,  0,  0,  0 }, /* south */
			{ 4, -1,  0,  0, +1, -2, +1, -1, +2 }, /* south west */
			{ 1, -1,  0,  0,  0,  0,  0,  0,  0 }, /* west */
			{ 4, -1,  0,  0, -1, -2, -1, -1, -2 }  /* north west */
		},

		{
			/* blue pixel - checked OK */
			{ 2,  0,  0,  0, -2,  0,  0,  0,  0 }, /* north */
			{ 2,  0,  0, +2, -2,  0,  0,  0,  0 }, /* north east */
			{ 2,  0,  0, +2,  0,  0,  0,  0,  0 }, /* east */
			{ 2,  0,  0, +2, +2,  0,  0,  0,  0 }, /* south east */
			{ 2,  0,  0,  0, +2,  0,  0,  0,  0 }, /* south */
			{ 2,  0,  0, -2, +2,  0,  0,  0,  0 }, /* south west */
			{ 2,  0,  0, -2,  0,  0,  0,  0,  0 }, /* west */
			{ 2,  0,  0, -2, -2,  0,  0,  0,  0 }  /* north west */
		},

	},

	/* green-on-blue row [CFA_GREEN_BLUE] */
	{

		{
			/* green-on-blue row, red pixel */
			{ 1,  0, -1,  0,  0,  0,  0,  0,  0 }, /* north */
			{ 2, +2, -1,  0, -1,  0,  0,  0,  0 }, /* north east */
			{ 4, +2, -1, +2, +1,  0, -1,  0, +1 }, /* east */
			{ 2, +2, +1,  0, +1,  0,  0,  0,  0 }, /* south east */
			{ 1,  0, +1,  0,  0,  0,  0,  0,  0 }, /* south */
			{ 2, -2, +1,  0, +1,  0,  0,  0,  0 }, /* south west */
			{ 4, -2, +1, -2, -1,  0, -1,  0, +1 }, /* west */
			{ 2, -2, -1,  0, -1,  0,  0,  0,  0 }  /* north west */
		},

		{
			/* green centre, green pixel */
			{ 2,  0, -2,  0,  0,  0,  0,  0,  0 }, /* north */
			{ 1, +1, -1,  0,  0,  0,  0,  0,  0 }, /* north east */
			{ 2, +2,  0,  0,  0,  0,  0,  0,  0 }, /* east */
			{ 1, +1, +1,  0,  0,  0,  0,  0,  0 }, /* south east */
			{ 2,  0, +2,  0,  0,  0,  0,  0,  0 }, /* south */
			{ 1, -1  +1,  0,  0,  0,  0,  0,  0 }, /* south west */
			{ 2, -2,  0,  0,  0,  0,  0,  0,  0 }, /* west */
			{ 1, -1, -1,  0,  0,  0,  0,  0,  0 }  /* north west */
		},

		{

			/* green-on-blue row, blue pixel */
			{ 4, +1,  0, +1, -2, -1,  0, -1, -2 }, /* north */
			{ 2, +1,  0, +1, -2,  0,  0,  0,  0 }, /* north east */
			{ 1, +1,  0,  0,  0,  0,  0,  0,  0 }, /* east */
			{ 2, +1,  0, +1, +2,  0,  0,  0,  0 }, /* south east */
			{ 4, +1,  0, +1, +2, -1,  0, -1, +2 }, /* south */
			{ 2, -1, +2, -1,  0,  0,  0,  0,  0 }, /* south west */
			{ 1, -1,  0,  0,  0,  0,  0,  0,  0 }, /* west */
			{ 2, -1,  0, -1, -2,  0,  0,  0,  0 }  /* north west */
		}
	},

	/* green-on-red row [CFA_GREEN_RED] */
	{
		{
			/* green-on-red row, red pixel */
			{ 4, +1,  0, +1, -2, -1,  0, -1, -2 }, /* north */
			{ 2, +1,  0, +1, -2,  0,  0,  0,  0 }, /* north east */
			{ 1, +1,  0,  0,  0,  0,  0,  0,  0 }, /* east */
			{ 2, +1,  0, +1, +2,  0,  0,  0,  0 }, /* south east */
			{ 4, +1,  0, +1, +2, -1,  0, -1, +2 }, /* south */
			{ 2, -1, +2, -1,  0,  0,  0,  0,  0 }, /* south west */
			{ 1, -1,  0,  0,  0,  0,  0,  0,  0 }, /* west */
			{ 2, -1,  0, -1, -2,  0,  0,  0,  0 }  /* north west */
		},

		{
			/* green centre, green pixel */
			{ 2,  0, -2,  0,  0,  0,  0,  0,  0 }, /* north */
			{ 1, +1, -1,  0,  0,  0,  0,  0,  0 }, /* north east */
			{ 2, +2,  0,  0,  0,  0,  0,  0,  0 }, /* east */
			{ 1, +1, +1,  0,  0,  0,  0,  0,  0 }, /* south east */
			{ 2,  0, +2,  0,  0,  0,  0,  0,  0 }, /* south */
			{ 1, -1  +1,  0,  0,  0,  0,  0,  0 }, /* south west */
			{ 2, -2,  0,  0,  0,  0,  0,  0,  0 }, /* west */
			{ 1, -1, -1,  0,  0,  0,  0,  0,  0 }  /* north west */
		},

		{
			/* green-on-red row, blue pixel */
			{ 1,  0, -1,  0,  0,  0,  0,  0,  0 }, /* north */
			{ 2, +2, -1,  0, -1,  0,  0,  0,  0 }, /* north east */
			{ 4, +2, -1, +2, +1,  0, -1,  0, +1 }, /* east */
			{ 2, +2, +1,  0, +1,  0,  0,  0,  0 }, /* south east */
			{ 1,  0, +1,  0,  0,  0,  0,  0,  0 }, /* south */
			{ 2, -2, +1,  0, +1,  0,  0,  0,  0 }, /* south west */
			{ 4, -2, +1, -2, -1,  0, -1,  0, +1 }, /* west */
			{ 2, -2, -1,  0, -1,  0,  0,  0,  0 }  /* north west */
		}

	}

};

 
/*
 * Arguments:
 *	struct raw *raw
 *		The RAW image structure. The RAW structure contains all the
 *		information about the size and layout of the sensor data
 *		including the CFA order and colours.
 *	int x_offset, y_offset
 *		Most CFAs have a dark border. This defines the offset of
 *		the first valid pixel, which must be compatible with the
 *		CFA layout defined in the RAW structure.
 *
 * Implementation
 *
 * To make the code clearer and allow for later manual optimisation,
 * each set of operations is done over the whole array in order, rather
 * than completing the processing of each pixel at a time.
 *
 * The stages are:
 * 1. Calculate the 8 gradients and the thresholds for each type
 *    of CFA components. Store this in a byte, using one bit per
 *    direction (N, NE, E, SE, S, SW, W, NW)
 * 2. 

 */
int cfa_cpp_rgb(struct raw *raw, SENSORELEMENT_T * const s,
		u_int16_t *red, u_int16_t *green, u_int16_t *blue,
		int rgb);

int
cfa_demosaick_ccp(struct raw *raw, int x_offset, int y_offset)
{
	SENSORELEMENT_T *s;
	int x = 0, y = 0;
	int r;

	if ((x_offset & 1) || (y_offset & 1) ||
	    (x_offset < 2) || (y_offset < 2) ||
	    ((raw->rawrgb_x + 2) > (raw->sensor.width - x_offset)) ||
	    ((raw->rawrgb_y + 2) > (raw->sensor.height - y_offset))) {
		/* must be multiple of 2 and a border all around of 2*/
		warnx("cfa_demosaick_ccp: parameter error");
		return 0;
	}

	/* Calculate gradients and thresholds */
	for (y = 0; y < raw->rawrgb_y; y += 2) {
		for (x = 0; x < raw->rawrgb_x; x += 2) {
			/* sensor location */
			s = raw->sensorarray + x_offset + x +
			    (y_offset + y) * raw->sensor.width;

			/* offset into colour array */
			r = x + y * raw->rawrgb_x;

			/* red */
			cfa_cpp_rgb(raw, s, raw->rawrgb_r + r,
				    raw->rawrgb_g + r, raw->rawrgb_b + r,
				    CFA_RED);

			/* green-on-red-row */
			s++; /* one to the right */
			r++;
			cfa_cpp_rgb(raw, s, raw->rawrgb_r + r,
				    raw->rawrgb_g + r, raw->rawrgb_b + r,
				    CFA_GREEN_RED);

			/* blue */
			s += raw->sensor.width; /* one below */
			r += raw->rawrgb_x;
			cfa_cpp_rgb(raw, s, raw->rawrgb_r + r,
				    raw->rawrgb_g + r, raw->rawrgb_b + r,
				    CFA_BLUE);

			/* green-on-blue row */
			s--; /* one left */
			r--;
			cfa_cpp_rgb(raw, s, raw->rawrgb_r + r,
				    raw->rawrgb_g + r, raw->rawrgb_b + r,
				    CFA_GREEN_BLUE);
		}
	}

	return 1;
}

int
cfa_cpp_rgb(struct raw *raw, SENSORELEMENT_T * const sensor,
	    u_int16_t *red, u_int16_t *green, u_int16_t *blue,
	    int rgb)
{
	int gradient, diff;
	int p1, p2;
	const struct cfa_cpp_scan *sp = NULL;
	u_int32_t grad[CFA_DIRECTIONS];
	u_int32_t gmin, gmax;
	int colour, threshold;
	int i, weight;
	int sum[3], total[3];	/* need to do signed arithmetic on results */

	gmin = 0xffffffff;
	gmax = 0;

	for (gradient = 0; gradient < CFA_DIRECTIONS; gradient++) {
		grad[gradient] = 0;
		for (diff = 0; diff < CFA_DIFFS; diff++) {
			switch (rgb) {
			case CFA_RED:
			case CFA_BLUE:
				sp = &red_blue_scan[gradient][diff];
				break;

			case CFA_GREEN_RED:
			case CFA_GREEN_BLUE:
				sp = &green_scan[gradient][diff];
				break;
			}

			/* no more */
			if (sp->d == -1)
				break;

			p1 = *(sensor + sp->x1 + sp->y1 * raw->sensor.width);
			p2 = *(sensor + sp->x2 + sp->y2 * raw->sensor.width);

			grad[gradient] += abs(p1 - p2) >> sp->d;
		}

		if (grad[gradient] < gmin)
			gmin = grad[gradient];

		if (grad[gradient] > gmax)
			gmax = grad[gradient];
	}

#define	CFA_K1(m)	(((m) * 3) >> 1)	/* k1 = 1.5 */
#define	CFA_K2(m)	((m) >> 1)		/* k2 = 0.5 */

	threshold = CFA_K1(gmin) + CFA_K2(gmax - gmin);

	/* set starting conditions */
	diff = 0;
	for (i = 0; i < raw->rawrgb_d; i++)
		sum[i] = 0;

	for (gradient = 0; gradient < CFA_DIRECTIONS; gradient++) {
		if (grad[gradient] > threshold)	/* don't use */
			continue;

		diff++;
		for (colour = 0; colour < raw->rawrgb_d; colour++) {
			int samples = rgb_average[rgb][colour][gradient][0];
			for (i = 0, weight = 0; i < samples; i++) {
				weight += *(sensor +
					   rgb_average[rgb][colour][gradient][i*2+1] +
					   rgb_average[rgb][colour][gradient][i*2+2] * raw->sensor.width);
			}
			sum[colour] += (weight / samples);
		}
	}

	switch (rgb) {
	case CFA_RED:
		total[0]	= *sensor;
 		total[1]	= *sensor + (sum[1] - sum[0]) / diff;
 		total[2]	= *sensor + (sum[2] - sum[0]) / diff;
		break;

	case CFA_BLUE:
 		total[0]	= *sensor + (sum[0] - sum[2]) / diff;
 		total[1]	= *sensor + (sum[1] - sum[2]) / diff;
		total[2]	= *sensor;
		break;

	case CFA_GREEN_BLUE:
	case CFA_GREEN_RED:
 		total[0]	= *sensor + (sum[0] - sum[1]) / diff;
		total[1]	= *sensor;
 		total[2]	= *sensor + (sum[2] - sum[1]) / diff;
		break;

	default:
		return 0;
	}

	total[0] = total[0] < 0 ? 0 : total[0];
	total[1] = total[1] < 0 ? 0 : total[1];
	total[2] = total[2] < 0 ? 0 : total[2];

	*red	= total[0] > 0xfff ? 0xfff : total[0];
	*green	= total[1] > 0xfff ? 0xfff : total[1];
	*blue	= total[2] > 0xfff ? 0xfff : total[2];

	return 1;
}
