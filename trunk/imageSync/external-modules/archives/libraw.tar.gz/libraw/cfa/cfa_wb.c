/* $Id: cfa_wb.c,v 1.3 2002/05/10 10:22:35 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <err.h>

#include <raw.h>

/*
 * Perform white balance before demosaik
 *
 * Apply the WB proportions to each of the four sensors in the array
 * based on the values in the raw->sensor structure.
 */
int
cfa_wb(struct raw *raw, int algorithm, cameraWB wb)
{
	u_int32_t x, y;
	u_int16_t *wbp = raw->sensor.wb[wb];
	int w = raw->sensor.width;
	SENSORELEMENT_T *sensor = raw->sensorarray;

	RDEBUG(("WB: applying %04x, %04x, %04x, %04x\n",
		wbp[0], wbp[1], wbp[2], wbp[3]));

	switch (raw->type) {
	case RAW_TYPE_CANON:
		for (y = 0; y < raw->sensor.height; y += 2, sensor += w * 2)
		{
			for (x = 0; x < w; x += 2)
			{
				SENSORELEMENT_T *s = sensor + x;
				u_int32_t r, g1, g2, b;

				switch (raw->subtype) {
				case RAW_TYPE_CANON_D60:
					r = s[0] * wbp[0];
					s[0] = r >> 8;

					g1 = s[1] * wbp[1];
					s[1] = g1 >> 8;

					g2 = s[w] * wbp[2];
					s[w] = g2 >> 8;

					b = s[w+1] * wbp[3];
					s[w+1] = b >> 8;
					break;
				case RAW_TYPE_CANON_D30:
				default:
				}
			}
		}
	}

	return 1;
}
