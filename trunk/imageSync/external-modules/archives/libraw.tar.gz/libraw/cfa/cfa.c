/* $Id: cfa.c,v 1.10 2002/05/10 10:22:35 peter Exp $ */

/*
 * Copyright (c) 2001 Peter Galbavy.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <err.h>

#include <raw.h>

/*
 * Set up common CFA demosaik memory allocations etc. and call
 * alghorithm specific function
 */
int
cfa_demosaick(struct raw *raw, int algorithm,
	      int x_offset, int y_offset,
	      int x_out, int y_out)
{
	if (raw->sensor.cfa != RAW_CFA_RGGB) {
		/* we currently only support the Bayer matrix:
		 *
		 *	R G R G
		 *	G B G B
		 */
		warnx("cfa_demosaick: wrong CFA type");
		return 1;
	}

	raw->rawrgb_x = x_out;
	raw->rawrgb_y = y_out;
	raw->rawrgb_d = 3;

	if ((raw->rawrgb_r = malloc(raw->rawrgb_x * raw->rawrgb_y *
				    sizeof(COLOURDEPTH_T))) == NULL) {
		warn("cfa_demosaick: rawrgb_r malloc failed");
		return 0;
	}

	if ((raw->rawrgb_g = malloc(raw->rawrgb_x * raw->rawrgb_y *
				    sizeof(COLOURDEPTH_T))) == NULL) {
		warn("cfa_demosaick: rawrgb_g malloc failed");
		return 0;
	}

	if ((raw->rawrgb_b = malloc(raw->rawrgb_x * raw->rawrgb_y *
				    sizeof(COLOURDEPTH_T))) == NULL) {
		warn("cfa_demosaick: rawrgb_b malloc failed");
		return 0;
	}

	switch (algorithm) {
	case CFA_ALG_CCP:
		return cfa_demosaick_ccp(raw, x_offset, y_offset);
	case CFA_ALG_NEAREST_NEIGHBOUR:
		return cfa_demosaick_nearest_neighbour(raw, x_offset, y_offset);
	default:
		fprintf(stderr, "Unknown CCP algorithm\n");
		return 0;
	}
}

void
cfa_subtract_black(struct raw *raw,
		   const u_int16_t x_offset, const u_int16_t y_offset)
{
	int w = raw->sensor.width;
	SENSORELEMENT_T *sensor = raw->sensorarray;
	SENSORELEMENT_T *sensorend = raw->sensorarray + (raw->sensor.width * raw->sensor.height);
	SENSORELEMENT_T *sp = sensor;

	SENSORELEMENT_T black = *(sensor + w * y_offset + x_offset);

	RDEBUG(("subtracting 0x%x black level\n", black));

	for (sp = sensor; sp < sensorend; sp++) 
		*sp -= black;
}
