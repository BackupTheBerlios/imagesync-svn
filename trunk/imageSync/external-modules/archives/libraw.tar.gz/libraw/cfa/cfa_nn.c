/* $Id: cfa_nn.c,v 1.3 2002/05/10 10:22:35 peter Exp $ */

/*
 * Copyright (c) 2002 Chris Breeze.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <err.h>

#include <raw.h>

/*
 * Simple nearest neighbour averaging
 * Chris Breeze, 01/04/2002
 */
int
cfa_demosaick_nearest_neighbour(struct raw *raw, int x_offset, int y_offset)
{
	SENSORELEMENT_T *sensor;
	int x = 0, y = 0;
	int r;

	if ((x_offset & 1) || (y_offset & 1) ||
	    (x_offset < 2) || (y_offset < 2) ||
	    ((raw->rawrgb_x + 2) > (raw->sensor.width - x_offset)) ||
	    ((raw->rawrgb_y + 2) > (raw->sensor.height - y_offset)))
	{
		/* must be multiple of 2 and a border all around of 2*/
		warnx("cfa_demosaick_nn: parameter error");
		return 0;
	}

	sensor = raw->sensorarray + x_offset + y_offset * raw->sensor.width;
	for (y = 0; y < raw->rawrgb_y; y += 2, sensor += raw->sensor.width * 2)
	{
		int w = raw->sensor.width;
		for (x = 0; x < raw->rawrgb_x; x += 2)
		{
			/* sensor location */
			SENSORELEMENT_T *s = sensor + x;

			/* offset into colour array */
			r = x + y * raw->rawrgb_x;

			/* red
			B G B
			G R G
			B G B
			*/
			*(raw->rawrgb_r + r) = *s;
			*(raw->rawrgb_g + r) = (s[-w] + s[-1] + s[1] + s[w]) >> 2;
			*(raw->rawrgb_b + r) = (s[-w - 1] + s[1 - w] + s[w - 1] + s[w + 1]) >> 2;

			/* green-on-red-row
			G B G
			R G R
			G B G
			*/
			s++; /* one to the right */
			r++;
			*(raw->rawrgb_r + r) = (s[-1] + s[1]) >> 1;
			*(raw->rawrgb_g + r) = *s;
			*(raw->rawrgb_b + r) = (s[-w] + s[w]) >> 1;

			/* blue
			R G R
			G B G
			R G R
			*/
			s += raw->sensor.width; /* one below */
			r += raw->rawrgb_x;
			*(raw->rawrgb_r + r) = (s[-w - 1] + s[1 - w] + s[w - 1] + s[w + 1]) >> 2;
			*(raw->rawrgb_g + r) = (s[-w] + s[-1] + s[1] + s[w]) >> 2;
			*(raw->rawrgb_b + r) = *s;

			/* green-on-blue row
			G R G
			B G B
			G R G
			*/
			s--; /* one left */
			r--;
			*(raw->rawrgb_r + r) = (s[-w] + s[w]) >> 1;
			*(raw->rawrgb_g + r) = *s;
			*(raw->rawrgb_b + r) = (s[-1] + s[1]) >> 1;
		}
	}

	return 1;
}
